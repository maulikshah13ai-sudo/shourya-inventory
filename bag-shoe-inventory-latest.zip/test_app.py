import unittest
import json
from app import app
from database import get_connection

class InventoryAppTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()
        self.client.testing = True
        conn = get_connection()
        conn.execute("DELETE FROM products WHERE sku = 'NEW-BAG-999'")
        conn.commit()
        conn.close()

    def login_as(self, username, password):
        return self.client.post('/login', data={'username': username, 'password': password}, follow_redirects=True)

    def test_login_and_logout(self):
        res = self.login_as('admin', 'admin123')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Shop Overview', res.data)

        # Logout
        res_logout = self.client.get('/logout', follow_redirects=True)
        self.assertEqual(res_logout.status_code, 200)
        self.assertIn(b'Staff Sign In', res_logout.data)

    def test_dashboard_admin(self):
        self.login_as('admin', 'admin123')
        res = self.client.get('/')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Shop Overview', res.data)

    def test_salesman_role_restrictions(self):
        # Login as Salesman
        self.login_as('sales1', 'sales123')

        # Salesman can access POS
        res_pos = self.client.get('/pos')
        self.assertEqual(res_pos.status_code, 200)

        # Salesman CANNOT access settings (redirects)
        res_settings = self.client.get('/settings', follow_redirects=True)
        self.assertIn(b'Access Restricted', res_settings.data)

        # Salesman CANNOT access purchases / stock in
        res_pur = self.client.get('/purchases', follow_redirects=True)
        self.assertIn(b'Access Restricted', res_pur.data)

    def test_warehouse_role_access(self):
        # Login as warehouse
        self.login_as('godown', 'godown123')

        # Can access stock in
        res_pur = self.client.get('/purchases')
        self.assertEqual(res_pur.status_code, 200)

        # Cannot access accounting khata ledger
        res_ledger = self.client.get('/ledger', follow_redirects=True)
        self.assertIn(b'Access Restricted', res_ledger.data)

    def test_accounting_role_access(self):
        # Login as accountant
        self.login_as('accounts', 'accounts123')

        # Can access wholesale khata ledger
        res_ledger = self.client.get('/ledger')
        self.assertEqual(res_ledger.status_code, 200)
        self.assertIn(b'Wholesale Credit Ledger', res_ledger.data)

    def test_inventory_page(self):
        self.login_as('admin', 'admin123')
        res = self.client.get('/inventory')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Products & Stock Catalog', res.data)

    def test_pos_page(self):
        self.login_as('admin', 'admin123')
        res = self.client.get('/pos')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Billing Mode:', res.data)

    def test_purchases_page(self):
        self.login_as('admin', 'admin123')
        res = self.client.get('/purchases')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Stock In', res.data)

    def test_sales_page(self):
        self.login_as('admin', 'admin123')
        res = self.client.get('/sales')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Sales History', res.data)

    def test_sale_creation_and_stock_deduction(self):
        self.login_as('sales1', 'sales123')
        conn = get_connection()
        prod = conn.execute("SELECT id, stock_qty, retail_price FROM products WHERE stock_qty > 2 LIMIT 1").fetchone()
        conn.close()
        self.assertIsNotNone(prod)
        prod_id = prod['id']
        initial_stock = prod['stock_qty']

        payload = {
            'sale_type': 'RETAIL',
            'customer_name': 'Multi-User Customer',
            'customer_phone': '9876543210',
            'subtotal': prod['retail_price'] * 2,
            'discount': 0,
            'grand_total': prod['retail_price'] * 2,
            'payment_mode': 'CASH',
            'paid_amount': prod['retail_price'] * 2,
            'items': [
                {
                    'id': prod_id,
                    'quantity': 2,
                    'price': prod['retail_price']
                }
            ]
        }

        res = self.client.post('/api/sales/create', json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        sale_id = data['sale_id']

        # Verify stock decreased by 2
        conn = get_connection()
        updated_prod = conn.execute("SELECT stock_qty FROM products WHERE id = ?", (prod_id,)).fetchone()
        conn.close()
        self.assertEqual(updated_prod['stock_qty'], initial_stock - 2)

        # Verify print invoice route
        res_inv = self.client.get(f'/invoice/{sale_id}')
        self.assertEqual(res_inv.status_code, 200)
        self.assertIn(b'Multi-User Customer', res_inv.data)

    def test_export_csv(self):
        self.login_as('accounts', 'accounts123')
        res = self.client.get('/export/inventory/csv')
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.mimetype, 'text/csv')

    def test_multi_salesman_concurrency_and_numbering(self):
        """Test that multiple salesmen billing generate strictly consecutive unique bill numbers and salesman tags."""
        conn = get_connection()
        prod = conn.execute("SELECT id, retail_price FROM products WHERE stock_qty > 20 LIMIT 1").fetchone()
        conn.close()
        prod_id = prod['id']
        price = prod['retail_price']

        generated_invoices = []
        for i in range(1, 6):
            self.client.get('/logout')
            self.login_as(f'sales{i}', 'sales123')
            payload = {
                'sale_type': 'RETAIL',
                'customer_name': f'Customer of Salesman {i}',
                'customer_phone': f'980000000{i}',
                'subtotal': price,
                'discount': 0,
                'grand_total': price,
                'payment_mode': 'CASH',
                'paid_amount': price,
                'items': [{'id': prod_id, 'quantity': 1, 'price': price}]
            }
            res = self.client.post('/api/sales/create', json=payload)
            self.assertEqual(res.status_code, 200)
            data = res.get_json()
            self.assertTrue(data['success'])
            generated_invoices.append(data['invoice_no'])

            # Verify bill print shows salesman name
            inv_res = self.client.get(f"/invoice/{data['sale_id']}")
            self.assertIn(f'Sales Staff {i}'.encode(), inv_res.data)

        # Ensure all invoice numbers are unique
        self.assertEqual(len(generated_invoices), len(set(generated_invoices)))
        # Verify prefix and sequence format
        for inv in generated_invoices:
            self.assertTrue(inv.startswith('SSIPL-'))

    def test_ten_parallel_salesmen_stress_concurrency(self):
        """Test true concurrent multi-threading: 10 salesmen hitting complete sale simultaneously."""
        from concurrent.futures import ThreadPoolExecutor
        conn = get_connection()
        prod = conn.execute("SELECT id, retail_price FROM products WHERE stock_qty > 20 LIMIT 1").fetchone()
        conn.close()
        prod_id = prod['id']
        price = prod['retail_price']

        def checkout_task(worker_id):
            client = app.test_client()
            client.post('/login', data={'username': f'sales{worker_id}', 'password': 'sales123'})
            payload = {
                'sale_type': 'RETAIL',
                'customer_name': f'Stress Customer {worker_id}',
                'subtotal': price,
                'discount': 0,
                'grand_total': price,
                'payment_mode': 'CASH',
                'paid_amount': price,
                'items': [{'id': prod_id, 'quantity': 1, 'price': price}]
            }
            res = client.post('/api/sales/create', json=payload)
            self.assertEqual(res.status_code, 200)
            return res.get_json()['invoice_no']

        with ThreadPoolExecutor(max_workers=10) as executor:
            invoices = list(executor.map(checkout_task, range(1, 11)))

        self.assertEqual(len(invoices), 10)
        self.assertEqual(len(set(invoices)), 10)  # Exactly 10 unique invoice numbers, 0 duplicates!

    def test_bulk_templates_downloads(self):
        """Test downloading both Excel and CSV templates for bulk purchase and sale."""
        self.login_as('admin', 'admin123')
        # Purchase templates
        res_p_xlsx = self.client.get('/export/template/bulk-purchase?format=xlsx')
        self.assertEqual(res_p_xlsx.status_code, 200)
        self.assertIn(b'spreadsheetml', res_p_xlsx.content_type.encode())

        res_p_csv = self.client.get('/export/template/bulk-purchase?format=csv')
        self.assertEqual(res_p_csv.status_code, 200)
        self.assertIn(b'text/csv', res_p_csv.content_type.encode())

        # Sale templates
        res_s_xlsx = self.client.get('/export/template/bulk-sale?format=xlsx')
        self.assertEqual(res_s_xlsx.status_code, 200)
        self.assertIn(b'spreadsheetml', res_s_xlsx.content_type.encode())

        res_s_csv = self.client.get('/export/template/bulk-sale?format=csv')
        self.assertEqual(res_s_csv.status_code, 200)
        self.assertIn(b'text/csv', res_s_csv.content_type.encode())

    def test_bulk_purchase_excel_upload(self):
        """Test uploading bulk purchase Excel file and stock increment."""
        import io, openpyxl
        self.login_as('admin', 'admin123')

        # Get existing product to restock
        conn = get_connection()
        prod = conn.execute("SELECT sku, stock_qty FROM products LIMIT 1").fetchone()
        conn.close()
        existing_sku = prod['sku']
        initial_stock = prod['stock_qty']

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Bulk_Purchase_Data"
        headers = ["Supplier Name", "Supplier Invoice No", "Purchase Date", "SKU", "Product Name", "Category", "Quantity", "Unit Cost Price", "Wholesale Price", "Retail Price"]
        ws.append(headers)
        ws.append(["Excel Factory Ltd", "EXCEL-INV-001", "2026-11-03", existing_sku, "Existing Product", "Bags", 25, 400.0, 600.0, 999.0])
        ws.append(["Excel Factory Ltd", "EXCEL-INV-001", "2026-11-03", "NEW-BAG-999", "New Travel Duffel Bag", "Bags", 15, 500.0, 750.0, 1299.0])

        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)

        data = {
            'file': (buf, 'shipment.xlsx')
        }
        res = self.client.post('/api/purchases/upload-excel', data=data, content_type='multipart/form-data')
        self.assertEqual(res.status_code, 200)
        res_data = res.get_json()
        self.assertTrue(res_data['success'])

        # Verify existing product stock increased by 25
        conn = get_connection()
        upd = conn.execute("SELECT stock_qty FROM products WHERE sku = ?", (existing_sku,)).fetchone()
        self.assertEqual(upd['stock_qty'], initial_stock + 25)

        # Verify new product was inserted into catalog
        new_prod = conn.execute("SELECT stock_qty, name FROM products WHERE sku = 'NEW-BAG-999'").fetchone()
        conn.close()
        self.assertIsNotNone(new_prod)
        self.assertEqual(new_prod['stock_qty'], 15)

    def test_bulk_sale_excel_upload(self):
        """Test uploading bulk sales Excel file and stock deduction."""
        import io, openpyxl
        self.login_as('admin', 'admin123')

        conn = get_connection()
        prod = conn.execute("SELECT sku, stock_qty, retail_price FROM products WHERE stock_qty > 10 LIMIT 1").fetchone()
        conn.close()
        sku = prod['sku']
        initial_stock = prod['stock_qty']
        price = prod['retail_price']

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Bulk_Sale_Data"
        headers = ["Customer Name", "Customer Phone", "Sale Type", "Payment Mode", "Order Reference", "SKU", "Quantity", "Unit Price", "Discount", "Paid Amount"]
        ws.append(headers)
        ws.append(["Bulk Buyer Rajesh", "9870001111", "WHOLESALE", "CASH", "BULK-ORD-01", sku, 5, price, 0, price * 5])

        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)

        data = {
            'file': (buf, 'bulk_sales.xlsx')
        }
        res = self.client.post('/api/sales/upload-excel', data=data, content_type='multipart/form-data')
        self.assertEqual(res.status_code, 200)
        res_data = res.get_json()
        self.assertTrue(res_data['success'])

        # Verify stock decreased by 5
        conn = get_connection()
        upd = conn.execute("SELECT stock_qty FROM products WHERE sku = ?", (sku,)).fetchone()
        conn.close()
        self.assertEqual(upd['stock_qty'], initial_stock - 5)

    def test_estimate_advance_booking_and_dispatch_workflow(self):
        """Test full Estimate / Sales Order lifecycle: Advance Booking -> Voucher -> Later Dispatch & Billing."""
        self.login_as('sales1', 'sales123')

        conn = get_connection()
        prod = conn.execute("SELECT id, retail_price, stock_qty FROM products WHERE stock_qty > 10 LIMIT 1").fetchone()
        conn.close()
        prod_id = prod['id']
        price = prod['retail_price']
        initial_stock = prod['stock_qty']

        # 1. Book Order with Advance Payment
        booking_payload = {
            'customer_name': 'Advance Booking Customer',
            'customer_phone': '9822233344',
            'order_type': 'WHOLESALE',
            'subtotal': price * 4,
            'discount': 0,
            'grand_total': price * 4,
            'advance_amount': 1000.0,
            'advance_payment_mode': 'UPI',
            'expected_dispatch_date': '2026-11-10',
            'notes': 'Pack securely for transport',
            'items': [{'id': prod_id, 'quantity': 4, 'price': price}]
        }
        res = self.client.post('/api/estimates/create', json=booking_payload)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        est_id = data['estimate_id']
        self.assertTrue(data['estimate_no'].startswith('EST-'))

        # Verify stock was NOT deducted during advance booking
        conn = get_connection()
        p_check = conn.execute("SELECT stock_qty FROM products WHERE id = ?", (prod_id,)).fetchone()
        conn.close()
        self.assertEqual(p_check['stock_qty'], initial_stock)

        # 2. View Estimate Voucher
        res_vouch = self.client.get(f'/estimate/{est_id}/print')
        self.assertEqual(res_vouch.status_code, 200)
        self.assertIn(b'Advance Booking Customer', res_vouch.data)
        self.assertIn(b'Advance Paid Token', res_vouch.data)

        # 3. Later Dispatch: Convert to Tax Invoice
        dispatch_payload = {
            'additional_paid_amount': (price * 4) - 1000.0, # Pay remaining balance
            'dispatch_payment_mode': 'CASH'
        }
        res_disp = self.client.post(f'/api/estimates/{est_id}/dispatch', json=dispatch_payload)
        self.assertEqual(res_disp.status_code, 200)
        disp_data = res_disp.get_json()
        self.assertTrue(disp_data['success'])
        invoice_no = disp_data['invoice_no']
        self.assertTrue(invoice_no.startswith('SSIPL-'))

        # Verify physical stock IS NOW deducted by 4
        conn = get_connection()
        p_after = conn.execute("SELECT stock_qty FROM products WHERE id = ?", (prod_id,)).fetchone()
        # Verify estimate status is DISPATCHED
        est_row = conn.execute("SELECT status, converted_invoice_no FROM estimates WHERE id = ?", (est_id,)).fetchone()
        conn.close()
        self.assertEqual(p_after['stock_qty'], initial_stock - 4)
        self.assertEqual(est_row['status'], 'DISPATCHED')
        self.assertEqual(est_row['converted_invoice_no'], invoice_no)

        # 4. View Final Invoice: check advance adjusted is shown
        res_inv = self.client.get(f'/invoice/{disp_data["invoice_id"]}')
        self.assertEqual(res_inv.status_code, 200)
        self.assertIn(b'Less Advance Adjusted', res_inv.data)

    def test_gst_inclusive_calculations_and_hsn(self):
        """Test Indian GST inclusive calculation for bags (HSN 4202) and shoes (HSN 6404)."""
        import excel_helpers

        items = [
            {'name': 'Executive Laptop Bag', 'hsn_code': '4202', 'gst_rate': 18.0, 'quantity': 1, 'price': 1180.0},
            {'name': 'Sport Running Shoes', 'hsn_code': '6404', 'gst_rate': 18.0, 'quantity': 2, 'price': 1180.0}
        ]
        # Intra-state: CGST 9% + SGST 9%
        res = excel_helpers.calculate_gst_breakdown(items, is_interstate=False, prices_include_gst=True)
        self.assertEqual(res['grand_total'], 3540.0)
        self.assertEqual(res['taxable_total'], 3000.0)
        self.assertEqual(res['total_tax'], 540.0)
        self.assertEqual(res['cgst_total'], 270.0)
        self.assertEqual(res['sgst_total'], 270.0)
        self.assertEqual(res['igst_total'], 0.0)
        self.assertEqual(len(res['hsn_summary']), 2)

        # Inter-state: IGST 18%
        res_inter = excel_helpers.calculate_gst_breakdown(items, is_interstate=True, prices_include_gst=True)
        self.assertEqual(res_inter['cgst_total'], 0.0)
        self.assertEqual(res_inter['sgst_total'], 0.0)
        self.assertEqual(res_inter['igst_total'], 540.0)

    def test_sale_creation_stores_gst_breakdown(self):
        """Test that POS sale creates accurate GST fields on sales and sale_items."""
        self.login_as('sales1', 'sales123')
        conn = get_connection()
        prod = conn.execute("SELECT id, name, sku, category, retail_price, stock_qty FROM products WHERE stock_qty > 5 LIMIT 1").fetchone()
        conn.close()

        payload = {
            'sale_type': 'RETAIL',
            'customer_name': 'GST Retail Customer',
            'customer_phone': '9811122233',
            'payment_mode': 'CASH',
            'is_interstate': 0,
            'items': [{'id': prod['id'], 'quantity': 2, 'price': prod['retail_price']}]
        }
        res = self.client.post('/api/sales/create', json=payload)
        self.assertEqual(res.status_code, 200)
        sale_data = res.get_json()
        self.assertTrue(sale_data['success'])
        sale_id = sale_data['sale_id']

        # Verify database values
        conn = get_connection()
        sale_row = conn.execute("SELECT taxable_amount, cgst_amount, sgst_amount, total_tax, grand_total FROM sales WHERE id = ?", (sale_id,)).fetchone()
        item_row = conn.execute("SELECT hsn_code, gst_rate, taxable_amount, cgst_amount, sgst_amount, total_price FROM sale_items WHERE sale_id = ?", (sale_id,)).fetchone()
        conn.close()

        self.assertGreater(sale_row['taxable_amount'], 0)
        self.assertGreater(sale_row['cgst_amount'], 0)
        self.assertGreater(sale_row['sgst_amount'], 0)
        self.assertGreater(sale_row['total_tax'], 0)
        self.assertIn(item_row['hsn_code'], ['4202', '6404'])
        self.assertEqual(item_row['gst_rate'], 18.0)

        # Verify Invoice Print contains Rule 46 HSN Summary
        res_print = self.client.get(f'/invoice/{sale_id}')
        self.assertEqual(res_print.status_code, 200)
        self.assertIn(b'Rule 46 Compliant', res_print.data)
        self.assertIn(b'HSN/SAC', res_print.data)
        self.assertIn(b'CGST Rate', res_print.data)

    def test_gst_reports_and_gstr1_excel_export(self):
        """Test /gst-reports view and /export/gstr1 CA-ready Excel download."""
        import openpyxl, io
        self.login_as('admin', 'admin123')

        # 1. GST Reports Dashboard View
        res_rep = self.client.get('/gst-reports')
        self.assertEqual(res_rep.status_code, 200)
        self.assertIn(b'GST Reports & Tax Returns', res_rep.data)
        self.assertIn(b'Output GST', res_rep.data)
        self.assertIn(b'Table 12: HSN Wise', res_rep.data)

        # 2. GSTR-1 Excel File Export
        res_exp = self.client.get('/export/gstr1')
        self.assertEqual(res_exp.status_code, 200)
        self.assertEqual(res_exp.content_type, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

        # Verify sheets inside downloaded Excel file
        wb = openpyxl.load_workbook(io.BytesIO(res_exp.data))
        expected_sheets = ['GSTR-1 Overview', '4A_B2B_Invoices', '7_B2C_Retail_Sales', '12_HSN_Summary']
        for sheet_name in expected_sheets:
            self.assertIn(sheet_name, wb.sheetnames)

    def test_quick_create_party_and_wholesale_gst(self):
        """Test on-the-fly party registration from POS and Party GST Number handling in wholesale sale."""
        self.login_as('sales1', 'sales123')

        # 1. Quick Add New Party via API
        party_payload = {
            'name': 'Gujarat Luggage Hub',
            'gst_no': '24AAACH7409R1ZZ',
            'phone': '9876543210'
        }
        res = self.client.post('/api/parties/quick-create',
                               data=json.dumps(party_payload),
                               content_type='application/json')
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        self.assertEqual(data['party']['name'], 'Gujarat Luggage Hub')
        self.assertEqual(data['party']['gst_no'], '24AAACH7409R1ZZ')
        self.assertEqual(data['party']['state_code'], '24')
        self.assertEqual(data['party']['state_name'], 'Gujarat')
        party_id = data['party']['id']

        # 2. Re-submitting existing GSTIN should return existing party
        res_dup = self.client.post('/api/parties/quick-create',
                                   data=json.dumps(party_payload),
                                   content_type='application/json')
        self.assertEqual(res_dup.status_code, 200)
        dup_data = json.loads(res_dup.data)
        self.assertTrue(dup_data['success'])
        self.assertEqual(dup_data['party']['id'], party_id)

        # 3. Create Wholesale Sale with this Party & GSTIN
        sale_payload = {
            'sale_type': 'WHOLESALE',
            'customer_name': 'Gujarat Luggage Hub',
            'customer_phone': '9876543210',
            'customer_gst': '24AAACH7409R1ZZ',
            'party_id': party_id,
            'is_interstate': 1,
            'subtotal': 1500.0,
            'discount': 0.0,
            'grand_total': 1500.0,
            'payment_mode': 'CREDIT',
            'paid_amount': 0.0,
            'items': [
                {
                    'id': 1,
                    'quantity': 2,
                    'price': 750.0
                }
            ]
        }
        res_sale = self.client.post('/api/sales/create',
                                    data=json.dumps(sale_payload),
                                    content_type='application/json')
        self.assertEqual(res_sale.status_code, 200)
        sale_data = json.loads(res_sale.data)
        self.assertTrue(sale_data['success'])
        sale_id = sale_data['sale_id']

        # Verify sales table stored customer_gst
        conn = get_connection()
        s_row = conn.execute("SELECT customer_gst, party_id, sale_type FROM sales WHERE id = ?", (sale_id,)).fetchone()
        conn.close()
        self.assertEqual(s_row['customer_gst'], '24AAACH7409R1ZZ')
        self.assertEqual(s_row['party_id'], party_id)

        # 4. Verify Invoice Print contains Party GSTIN
        res_inv = self.client.get(f'/invoice/{sale_id}')
        self.assertEqual(res_inv.status_code, 200)
        self.assertIn(b'24AAACH7409R1ZZ', res_inv.data)
        self.assertIn(b'Gujarat Luggage Hub', res_inv.data)

        # 5. Verify Sales History table shows GSTIN
        res_sales = self.client.get('/sales')
        self.assertEqual(res_sales.status_code, 200)
        self.assertIn(b'24AAACH7409R1ZZ', res_sales.data)

    def test_sales_report_page_and_filters(self):
        self.login_as('admin', 'admin123')
        
        # Test /reports redirect
        res_redir = self.client.get('/reports', follow_redirects=False)
        self.assertEqual(res_redir.status_code, 302)
        self.assertIn('/reports/sales', res_redir.location)

        # Test Sales Report view
        res = self.client.get('/reports/sales')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Sales & Product Performance Reports', res.data)
        self.assertIn(b'Product-Wise Summary', res.data)
        self.assertIn(b'Gross Turnover', res.data)

        # Test Itemized Register view
        res_reg = self.client.get('/reports/sales?view=register')
        self.assertEqual(res_reg.status_code, 200)
        self.assertIn(b'Itemized Sales & Invoice Transaction Register', res_reg.data)

        # Test filter parameters
        res_filt = self.client.get('/reports/sales?category=Bags&sale_type=RETAIL&payment_mode=CASH')
        self.assertEqual(res_filt.status_code, 200)

    def test_purchase_report_page_and_filters(self):
        self.login_as('admin', 'admin123')

        # Test Purchase Report default view
        res = self.client.get('/reports/purchases')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Purchase & Inward Stock Reports', res.data)
        self.assertIn(b'Total Inward Qty', res.data)
        self.assertIn(b'Input Tax Credit (ITC)', res.data)

        # Test Itemized Register view
        res_reg = self.client.get('/reports/purchases?view=register')
        self.assertEqual(res_reg.status_code, 200)
        self.assertIn(b'Detailed Vendor Purchase Register', res_reg.data)

        # Test filter parameters
        res_filt = self.client.get('/reports/purchases?category=Shoes&payment_status=PAID')
        self.assertEqual(res_filt.status_code, 200)

    def test_reports_excel_and_csv_exports(self):
        self.login_as('admin', 'admin123')

        # Sales Excel Export
        res_s_xlsx = self.client.get('/export/reports/sales/excel')
        self.assertEqual(res_s_xlsx.status_code, 200)
        self.assertEqual(res_s_xlsx.content_type, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        self.assertTrue(len(res_s_xlsx.data) > 1000)

        # Sales CSV Export
        res_s_csv = self.client.get('/export/reports/sales/csv')
        self.assertEqual(res_s_csv.status_code, 200)
        self.assertIn('text/csv', res_s_csv.content_type)
        self.assertIn(b'Invoice_No', res_s_csv.data)

        # Purchase Excel Export
        res_p_xlsx = self.client.get('/export/reports/purchases/excel')
        self.assertEqual(res_p_xlsx.status_code, 200)
        self.assertEqual(res_p_xlsx.content_type, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        self.assertTrue(len(res_p_xlsx.data) > 1000)

        # Purchase CSV Export
        res_p_csv = self.client.get('/export/reports/purchases/csv')
        self.assertEqual(res_p_csv.status_code, 200)
        self.assertIn('text/csv', res_p_csv.content_type)
        self.assertIn(b'Bill_No', res_p_csv.data)

if __name__ == '__main__':
    unittest.main()
